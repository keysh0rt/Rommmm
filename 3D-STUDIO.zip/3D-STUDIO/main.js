let scene, camera, renderer, controls, loader;
let selectedObject = null;

// Initialize Scene
function init() {
  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 2, 5);

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setClearColor(0x1e1e1e); // Dark background
  document.getElementById('viewer').appendChild(renderer.domElement);

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
  scene.add(ambientLight);

  const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
  directionalLight.position.set(5, 5, 5);
  scene.add(directionalLight);

  controls = new THREE.OrbitControls(camera, renderer.domElement);

  // Window Resize
  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  animate();
}

// Clear Scene
function clearScene() {
  while (scene.children.length > 0) {
    scene.remove(scene.children[0]);
  }
}

// Load Model
function loadModel(file) {
  const fileName = file.name.toLowerCase();

  if (fileName.endsWith('.glb') || fileName.endsWith('.gltf')) {
    loader = new THREE.GLTFLoader();
    loader.load(URL.createObjectURL(file), (gltf) => {
      clearScene();
      selectedObject = gltf.scene;
      scene.add(selectedObject);
    });
  } else if (fileName.endsWith('.obj')) {
    alert('OBJ support requires a separate library.'); // Placeholder for OBJ loader
  } else if (fileName.endsWith('.fbx')) {
    alert('FBX support requires a separate library.'); // Placeholder for FBX loader
  } else {
    alert('Unsupported file type. Use GLB, OBJ, or FBX.');
  }
}

// Export Scene
function exportScene() {
  const exporter = new THREE.GLTFExporter();
  exporter.parse(
    scene,
    (result) => {
      const blob = new Blob([result], { type: 'application/octet-stream' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'scene.glb';
      a.click();
    },
    { binary: true }
  );
}

// Fullscreen
function goFullScreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen();
  } else {
    document.body.requestFullscreen();
  }
}

// Add Event Listeners
document.getElementById('newScene').addEventListener('click', clearScene);

document.getElementById('uploadModel').addEventListener('click', () => {
  document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', (event) => {
  loadModel(event.target.files[0]);
});

document.getElementById('exportModel').addEventListener('click', exportScene);

document.getElementById('fullScreen').addEventListener('click', goFullScreen);

// Animate
function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
  controls.update();
}

init();